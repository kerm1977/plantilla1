#Copyright ReportLab Europe Ltd. 2000-2017
#see license.txt for license details
#history https://hg.reportlab.com/hg-public/reportlab/log/tip/src/reportlab/pdfbase/__init__.py
__version__='3.3.0'
__doc__="""Internal functionality for creating PDF files - not part of API
"""
